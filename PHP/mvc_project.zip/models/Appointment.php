<?php
class Appointment {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data, $userID, $userRole) {
        if (!isset($data['serviceID']) || !isset($data['date']) || !isset($data['time'])) {
            return ['success' => false, 'message' => 'Datos incompletos.'];
        }

        $serviceID = $data['serviceID'];
        $date = $data['date'];
        $time = $data['time'];

        $stmt = $this->conn->prepare("INSERT INTO appointments (user_id, service_id, date, time) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $userID, $serviceID, $date, $time);

        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Cita creada.'];
        } else {
            return ['success' => false, 'message' => 'Error al crear cita.'];
        }
    }
}
