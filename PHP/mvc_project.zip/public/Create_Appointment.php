<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

session_start();

if (!isset($_SESSION['user']['id']) || !isset($_SESSION['user']['role'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado.']);
    exit();
}

require_once __DIR__ . '/../controllers/AppointmentController.php';

$host = "localhost";
$db = "AutoCareHub";
$user = "hmi";
$pass = "hmi";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de conexión.']);
    exit();
}

$controller = new AppointmentController($conn);

$data = json_decode(file_get_contents("php://input"), true);
$response = $controller->createAppointment($data, $_SESSION['user']['id'], $_SESSION['user']['role']);

echo json_encode($response);
