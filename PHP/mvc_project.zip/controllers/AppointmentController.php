<?php
require_once __DIR__ . '/../models/Appointment.php';

class AppointmentController {
    private $appointment;

    public function __construct($db) {
        $this->appointment = new Appointment($db);
    }

    public function createAppointment($requestData, $userID, $userRole) {
        return $this->appointment->create($requestData, $userID, $userRole);
    }
}
